# Pilot Assistant - DjSinning Protocol

โปรเจกต์นี้เป็น **ผู้ช่วยนักบิน** ในรูปแบบ Interactive Console App จำลองระบบ AI ecosystem

## ฟีเจอร์
- 4 Layer: Orchestrator, Prometheus, Evolution, Sovereign Doctrine
- Simulation 1,000-agent ecosystem
- Interactive Console สำหรับ R&D / Investor Demo
- สามารถ deploy เป็น .exe บน Windows ได้ทันที

## การติดตั้ง
1. ติดตั้ง [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
2. Clone repository:
   ```bash
   git clone https://github.com/YourUsername/PilotAssistant.git
   cd PilotAssistant/src
   ```
3. รันโปรแกรม:
   ```bash
   dotnet run
   ```

### การสร้าง .exe สำหรับ Deploy
```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

## License

© 2025 Chaiyaphop Nilpat (DjSinning)
MIT License (หรือเปลี่ยนตามต้องการ)