# คู่มือผู้ใช้ Pilot Assistant

## เริ่มต้นใช้งาน
1. ดาวน์โหลดไฟล์ .exe จากหน้า GitHub Release
2. ดับเบิลคลิกเพื่อเปิดโปรแกรม (Windows)
3. ใช้คำสั่งผ่าน Console (ดู Demo ใน README)

## ฟีเจอร์หลัก
- โหมด Simulation
- รองรับ AI Layer ทั้ง 4
- Interactive Commands

## ติดต่อผู้พัฒนา
Chaiyaphop Nilpat (DjSinning)