'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function SecurityPage() {
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);

  const securityStatus = [
    {
      title: 'รหัสผ่าน',
      status: 'ปลอดภัย',
      lastUpdate: '7 วันที่แล้ว',
      color: 'text-green-600 bg-green-100',
      icon: 'ri-lock-line'
    },
    {
      title: 'ยืนยันตัวตน 2 ขั้นตอน',
      status: 'เปิดใช้งาน',
      lastUpdate: '1 เดือนที่แล้ว',
      color: 'text-green-600 bg-green-100',
      icon: 'ri-shield-check-line'
    },
    {
      title: 'อุปกรณ์ที่เชื่อมต่อ',
      status: '3 อุปกรณ์',
      lastUpdate: '2 ชั่วโมงที่แล้ว',
      color: 'text-blue-600 bg-blue-100',
      icon: 'ri-device-line'
    },
    {
      title: 'การเข้าสู่ระบบ',
      status: 'กิจกรรมปกติ',
      lastUpdate: '5 นาทีที่แล้ว',
      color: 'text-green-600 bg-green-100',
      icon: 'ri-login-circle-line'
    }
  ];

  const recentActivity = [
    {
      action: 'เข้าสู่ระบบ',
      device: 'iPhone 15 Pro',
      location: 'กรุงเทพฯ, ไทย',
      time: '5 นาทีที่แล้ว',
      status: 'success'
    },
    {
      action: 'เปลี่ยนรหัสผ่าน',
      device: 'MacBook Pro',
      location: 'กรุงเทพฯ, ไทย',
      time: '7 วันที่แล้ว',
      status: 'success'
    },
    {
      action: 'ลองเข้าสู่ระบบ',
      device: 'Unknown Device',
      location: 'Unknown Location',
      time: '2 สัปดาห์ที่แล้ว',
      status: 'warning'
    }
  ];

  const securitySettings = [
    {
      title: 'ยืนยันตัวตน 2 ขั้นตอน',
      description: 'เพิ่มความปลอดภัยด้วย SMS หรือ Authenticator',
      enabled: twoFactorEnabled,
      toggle: () => setTwoFactorEnabled(!twoFactorEnabled)
    },
    {
      title: 'ล็อกด้วยลายนิ้วมือ',
      description: 'ใช้ลายนิ้วมือเพื่อเข้าสู่ระบบ',
      enabled: biometricEnabled,
      toggle: () => setBiometricEnabled(!biometricEnabled)
    },
    {
      title: 'แจ้งเตือนทางอีเมล',
      description: 'รับการแจ้งเตือนเมื่อมีการเข้าสู่ระบบ',
      enabled: emailNotifications,
      toggle: () => setEmailNotifications(!emailNotifications)
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="relative w-full h-40 mb-6 rounded-2xl overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=cybersecurity%20shield%20with%20digital%20lock%2C%20security%20protection%20interface%2C%20firewall%20visualization%2C%20encrypted%20data%20protection%2C%20blue%20and%20green%20gradient%2C%20modern%20security%20concept%2C%20digital%20safety%20technology&width=350&height=160&seq=security-hero&orientation=landscape"
                alt="Security"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">ความปลอดภัย</h1>
            <p className="text-gray-600 text-sm">ป้องกันบัญชีและข้อมูลของคุณ</p>
          </div>

          {/* Security Score */}
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-6 text-white mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-green-100 text-sm">คะแนนความปลอดภัย</p>
                <p className="text-3xl font-bold">85/100</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <i className="ri-shield-check-line text-2xl"></i>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-green-100 text-sm">ระดับ: ปลอดภัยดี</span>
              <Link
                href="/security/improve"
                className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-medium transition-colors !rounded-button"
              >
                ปรับปรุง
              </Link>
            </div>
          </div>

          {/* Security Status */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">สถานะความปลอดภัย</h3>
            <div className="space-y-4">
              {securityStatus.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full ${item.color} flex items-center justify-center mr-3`}>
                      <i className={`${item.icon} text-sm`}></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 text-sm">{item.title}</h4>
                      <p className="text-gray-500 text-xs">{item.lastUpdate}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-800 text-sm">{item.status}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Security Settings */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">การตั้งค่าความปลอดภัย</h3>
            <div className="space-y-4">
              {securitySettings.map((setting, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-800 text-sm">{setting.title}</h4>
                    <p className="text-gray-500 text-xs">{setting.description}</p>
                  </div>
                  <button
                    onClick={setting.toggle}
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      setting.enabled ? 'bg-blue-500' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute w-5 h-5 bg-white rounded-full top-0.5 transition-transform ${
                        setting.enabled ? 'translate-x-6' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">กิจกรรมล่าสุด</h3>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 mt-1 ${
                    activity.status === 'success' 
                      ? 'bg-green-100 text-green-600' 
                      : 'bg-yellow-100 text-yellow-600'
                  }`}>
                    <i className={`${
                      activity.status === 'success' ? 'ri-check-line' : 'ri-alert-line'
                    } text-xs`}></i>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-800 text-sm">{activity.action}</h4>
                      <span className="text-xs text-gray-500">{activity.time}</span>
                    </div>
                    <p className="text-gray-600 text-xs mt-1">{activity.device}</p>
                    <p className="text-gray-500 text-xs">{activity.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">การดำเนินการด่วน</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/security/change-password"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-lock-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">เปลี่ยนรหัสผ่าน</span>
              </Link>
              <Link
                href="/security/devices"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-device-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">จัดการอุปกรณ์</span>
              </Link>
              <Link
                href="/security/backup"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-download-cloud-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">สำรองข้อมูล</span>
              </Link>
              <Link
                href="/security/report"
                className="flex items-center justify-center p-3 bg-red-50 rounded-xl hover:bg-red-100 transition-colors"
              >
                <i className="ri-alarm-warning-line text-red-600 mr-2"></i>
                <span className="text-sm font-medium text-red-600">รายงานปัญหา</span>
              </Link>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}