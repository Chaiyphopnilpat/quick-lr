'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('products');
  const [searchTerm, setSearchTerm] = useState('');

  const products = [
    {
      id: 1,
      name: 'กาแฟอเมริกาโน',
      sku: 'COFFEE-001',
      category: 'เครื่องดื่ม',
      stock: 45,
      minStock: 20,
      price: 65,
      cost: 25,
      supplier: 'บริษัท กาแฟดี จำกัด',
      lastUpdated: '2025-01-15'
    },
    {
      id: 2,
      name: 'ข้าวผัดกุ้ง',
      sku: 'FOOD-002',
      category: 'อาหาร',
      stock: 12,
      minStock: 15,
      price: 120,
      cost: 60,
      supplier: 'ตลาดสดใหม่',
      lastUpdated: '2025-01-14'
    },
    {
      id: 3,
      name: 'คุกกี้ช็อกโกแลต',
      sku: 'SNACK-003',
      category: 'ขนม',
      stock: 85,
      minStock: 30,
      price: 35,
      cost: 18,
      supplier: 'เบเกอรี่โฮม',
      lastUpdated: '2025-01-15'
    },
    {
      id: 4,
      name: 'น้ำส้มคั้น',
      sku: 'DRINK-004',
      category: 'เครื่องดื่ม',
      stock: 8,
      minStock: 25,
      price: 45,
      cost: 20,
      supplier: 'ฟาร์มส้มออร์แกนิค',
      lastUpdated: '2025-01-13'
    }
  ];

  const lowStockProducts = products.filter(product => product.stock <= product.minStock);

  const stockMovements = [
    {
      id: 1,
      product: 'กาแฟอเมริกาโน',
      type: 'เพิ่ม',
      quantity: 50,
      reason: 'รับสินค้า',
      date: '2025-01-15',
      time: '14:30'
    },
    {
      id: 2,
      product: 'ข้าวผัดกุ้ง',
      type: 'ลด',
      quantity: 3,
      reason: 'ขาย',
      date: '2025-01-15',
      time: '13:45'
    },
    {
      id: 3,
      product: 'น้ำส้มคั้น',
      type: 'ลด',
      quantity: 2,
      reason: 'เสียหาย',
      date: '2025-01-14',
      time: '16:20'
    }
  ];

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {/* Header */}
          <div className="bg-white px-4 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-gray-800">จัดการสต๊อก</h1>
              <div className="flex items-center space-x-2">
                <Link
                  href="/pos/inventory/add"
                  className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center !rounded-button"
                >
                  <i className="ri-add-line"></i>
                </Link>
                <Link
                  href="/pos/inventory/scan"
                  className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center !rounded-button"
                >
                  <i className="ri-qr-scan-line"></i>
                </Link>
              </div>
            </div>
          </div>

          {/* Search */}
          <div className="bg-white px-4 py-3 border-b">
            <div className="relative">
              <input
                type="text"
                placeholder="ค้นหาสินค้า..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>

          {/* Alert - Low Stock */}
          {lowStockProducts.length > 0 && (
            <div className="bg-red-50 border border-red-200 mx-4 mt-4 rounded-xl p-4">
              <div className="flex items-center">
                <i className="ri-alert-line text-red-500 mr-2"></i>
                <span className="text-red-700 font-medium">
                  สินค้าใกล้หมด {lowStockProducts.length} รายการ
                </span>
              </div>
            </div>
          )}

          {/* Tab Navigation */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-1">
            <div className="flex">
              <button
                onClick={() => setActiveTab('products')}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors !rounded-button ${
                  activeTab === 'products'
                    ? 'bg-blue-500 text-white'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                สินค้าทั้งหมด
              </button>
              <button
                onClick={() => setActiveTab('movements')}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors !rounded-button ${
                  activeTab === 'movements'
                    ? 'bg-blue-500 text-white'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                การเคลื่อนไหว
              </button>
            </div>
          </div>

          {activeTab === 'products' && (
            <div className="mx-4 mt-4 space-y-3">
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 mb-1">{product.name}</h3>
                      <p className="text-gray-500 text-sm mb-2">SKU: {product.sku}</p>
                      <div className="flex items-center space-x-4 mb-2">
                        <div className="flex items-center">
                          <i className="ri-archive-line text-gray-400 mr-1"></i>
                          <span className={`text-sm font-medium ${
                            product.stock <= product.minStock ? 'text-red-600' : 'text-green-600'
                          }`}>
                            {product.stock} ชิ้น
                          </span>
                        </div>
                        <div className="flex items-center">
                          <i className="ri-price-tag-line text-gray-400 mr-1"></i>
                          <span className="text-sm text-gray-600">฿{product.price}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">
                          อัปเดต: {new Date(product.lastUpdated).toLocaleDateString('th-TH')}
                        </span>
                        <div className="flex items-center space-x-2">
                          <Link
                            href={`/pos/inventory/edit/${product.id}`}
                            className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center !rounded-button"
                          >
                            <i className="ri-edit-line text-sm"></i>
                          </Link>
                          <button className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center !rounded-button">
                            <i className="ri-add-line text-sm"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  {product.stock <= product.minStock && (
                    <div className="mt-3 bg-red-50 border border-red-200 rounded-lg p-2">
                      <p className="text-red-700 text-xs">
                        <i className="ri-alert-line mr-1"></i>
                        สินค้าใกล้หมด (ต่ำกว่า {product.minStock} ชิ้น)
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'movements' && (
            <div className="mx-4 mt-4 space-y-3">
              {stockMovements.map((movement) => (
                <div key={movement.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 mb-1">{movement.product}</h3>
                      <div className="flex items-center space-x-4 mb-2">
                        <div className={`flex items-center ${
                          movement.type === 'เพิ่ม' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          <i className={`${
                            movement.type === 'เพิ่ม' ? 'ri-add-line' : 'ri-subtract-line'
                          } mr-1`}></i>
                          <span className="text-sm font-medium">
                            {movement.type === 'เพิ่ม' ? '+' : '-'}{movement.quantity}
                          </span>
                        </div>
                        <span className="text-sm text-gray-600">{movement.reason}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">
                          {new Date(movement.date).toLocaleDateString('th-TH')} เวลา {movement.time}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Quick Actions */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">การดำเนินการด่วน</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/pos/inventory/receive"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-download-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">รับสินค้า</span>
              </Link>
              <Link
                href="/pos/inventory/count"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-file-list-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">นับสต๊อก</span>
              </Link>
              <Link
                href="/pos/inventory/adjust"
                className="flex items-center justify-center p-3 bg-yellow-50 rounded-xl hover:bg-yellow-100 transition-colors"
              >
                <i className="ri-edit-line text-yellow-600 mr-2"></i>
                <span className="text-sm font-medium text-yellow-600">ปรับปรุงสต๊อก</span>
              </Link>
              <Link
                href="/pos/inventory/report"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-bar-chart-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">รายงาน</span>
              </Link>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}