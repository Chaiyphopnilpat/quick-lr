
'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function POSPage() {
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCustomerDisplay, setShowCustomerDisplay] = useState(false);
  const [scannerActive, setScannerActive] = useState(false);

  const categories = [
    { id: 'all', name: 'ทั้งหมด', icon: 'ri-apps-line' },
    { id: 'food', name: 'อาหาร', icon: 'ri-restaurant-line' },
    { id: 'drink', name: 'เครื่องดื่ม', icon: 'ri-cup-line' },
    { id: 'snack', name: 'ขนม', icon: 'ri-cake-line' },
    { id: 'dessert', name: 'ของหวาน', icon: 'ri-cake-2-line' },
    { id: 'other', name: 'อื่นๆ', icon: 'ri-more-line' }
  ];

  const products = [
    {
      id: 1,
      name: 'กาแฟอเมริกาโน',
      price: 65,
      category: 'drink',
      barcode: '8851234567890',
      stock: 50,
      image: 'https://readdy.ai/api/search-image?query=americano%20coffee%20in%20white%20cup%2C%20black%20coffee%2C%20cafe%20drink%2C%20minimalist%20style%2C%20warm%20lighting%2C%20coffee%20shop%20aesthetic%2C%20professional%20food%20photography&width=100&height=100&seq=americano-1&orientation=squarish'
    },
    {
      id: 2,
      name: 'ข้าวผัดกุ้ง',
      price: 120,
      category: 'food',
      barcode: '8851234567891',
      stock: 25,
      image: 'https://readdy.ai/api/search-image?query=thai%20fried%20rice%20with%20shrimp%2C%20asian%20cuisine%2C%20delicious%20food%2C%20restaurant%20style%2C%20appetizing%20presentation%2C%20food%20photography&width=100&height=100&seq=fried-rice-1&orientation=squarish'
    },
    {
      id: 3,
      name: 'คุกกี้ช็อกโกแลต',
      price: 35,
      category: 'snack',
      barcode: '8851234567892',
      stock: 100,
      image: 'https://readdy.ai/api/search-image?query=chocolate%20chip%20cookies%2C%20baked%20goods%2C%20sweet%20treats%2C%20bakery%20items%2C%20golden%20brown%20cookies%2C%20food%20photography&width=100&height=100&seq=cookies-1&orientation=squarish'
    },
    {
      id: 4,
      name: 'น้ำส้มคั้น',
      price: 45,
      category: 'drink',
      barcode: '8851234567893',
      stock: 30,
      image: 'https://readdy.ai/api/search-image?query=fresh%20orange%20juice%20in%20glass%2C%20natural%20fruit%20juice%2C%20healthy%20beverage%2C%20citrus%20drink%2C%20refreshing%20drink%2C%20food%20photography&width=100&height=100&seq=orange-juice-1&orientation=squarish'
    },
    {
      id: 5,
      name: 'ส้มตำไทย',
      price: 80,
      category: 'food',
      barcode: '8851234567894',
      stock: 20,
      image: 'https://readdy.ai/api/search-image?query=thai%20papaya%20salad%20som%20tam%2C%20traditional%20thai%20food%2C%20spicy%20salad%2C%20authentic%20cuisine%2C%20street%20food%2C%20food%20photography&width=100&height=100&seq=som-tam-1&orientation=squarish'
    },
    {
      id: 6,
      name: 'ชาไทย',
      price: 55,
      category: 'drink',
      barcode: '8851234567895',
      stock: 40,
      image: 'https://readdy.ai/api/search-image?query=thai%20iced%20tea%2C%20orange%20colored%20drink%2C%20traditional%20thai%20beverage%2C%20sweet%20tea%2C%20refreshing%20drink%2C%20food%20photography&width=100&height=100&seq=thai-tea-1&orientation=squarish'
    },
    {
      id: 7,
      name: 'เค้กช็อกโกแลต',
      price: 95,
      category: 'dessert',
      barcode: '8851234567896',
      stock: 15,
      image: 'https://readdy.ai/api/search-image?query=chocolate%20cake%20slice%2C%20rich%20chocolate%20dessert%2C%20bakery%20cake%2C%20sweet%20treat%2C%20professional%20food%20photography&width=100&height=100&seq=cake-1&orientation=squarish'
    },
    {
      id: 8,
      name: 'ข้าวไข่เจียว',
      price: 45,
      category: 'food',
      barcode: '8851234567897',
      stock: 35,
      image: 'https://readdy.ai/api/search-image?query=thai%20fried%20rice%20with%20egg%2C%20simple%20thai%20food%2C%20comfort%20food%2C%20home%20cooking%20style%2C%20food%20photography&width=100&height=100&seq=egg-rice-1&orientation=squarish'
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const addToCart = (product) => {
    if (product.stock <= 0) {
      alert('สินค้าหมด');
      return;
    }
    
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      if (existingItem.quantity >= product.stock) {
        alert('สินค้าไม่เพียงพอ');
        return;
      }
      setCart(cart.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
    setTotal(total + product.price);
  };

  const removeFromCart = (productId) => {
    const item = cart.find(item => item.id === productId);
    if (item) {
      if (item.quantity > 1) {
        setCart(cart.map(item =>
          item.id === productId
            ? { ...item, quantity: item.quantity - 1 }
            : item
        ));
      } else {
        setCart(cart.filter(item => item.id !== productId));
      }
      setTotal(total - item.price);
    }
  };

  const clearCart = () => {
    setCart([]);
    setTotal(0);
  };

  const handleBarcodeScanner = () => {
    setScannerActive(true);
    // จำลองการสแกนบาร์โค้ด
    setTimeout(() => {
      const randomProduct = products[Math.floor(Math.random() * products.length)];
      addToCart(randomProduct);
      setScannerActive(false);
    }, 1500);
  };

  const toggleCustomerDisplay = () => {
    setShowCustomerDisplay(!showCustomerDisplay);
  };

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {/* Header */}
          <div className="bg-white px-4 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-gray-800">ระบบขายหน้าร้าน</h1>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleBarcodeScanner}
                  className={`w-10 h-10 rounded-full flex items-center justify-center !rounded-button ${
                    scannerActive ? 'bg-yellow-500' : 'bg-blue-500'
                  } text-white`}
                >
                  <i className={scannerActive ? 'ri-loader-line animate-spin' : 'ri-qr-scan-line'}></i>
                </button>
                <button
                  onClick={toggleCustomerDisplay}
                  className={`w-10 h-10 rounded-full flex items-center justify-center !rounded-button ${
                    showCustomerDisplay ? 'bg-green-500' : 'bg-gray-500'
                  } text-white`}
                >
                  <i className="ri-computer-line"></i>
                </button>
                <Link
                  href="/pos/inventory"
                  className="w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center !rounded-button"
                >
                  <i className="ri-archive-line"></i>
                </Link>
              </div>
            </div>
          </div>

          {/* Customer Display */}
          {showCustomerDisplay && (
            <div className="bg-black text-white mx-4 mt-4 rounded-xl p-4 shadow-lg">
              <h3 className="text-lg font-bold mb-2 text-center">จอแสดงผลลูกค้า</h3>
              <div className="text-center mb-4">
                <div className="text-3xl font-bold text-green-400">
                  ฿{total.toLocaleString()}
                </div>
                <div className="text-sm text-gray-300">ยอดรวม</div>
              </div>
              {cart.length > 0 && (
                <div className="space-y-2">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.name} x{item.quantity}</span>
                      <span>฿{(item.price * item.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Scanner Status */}
          {scannerActive && (
            <div className="bg-yellow-50 border border-yellow-200 mx-4 mt-4 rounded-xl p-4 text-center">
              <i className="ri-qr-scan-line text-yellow-600 text-2xl mb-2"></i>
              <p className="text-yellow-700 font-medium">กำลังสแกนบาร์โค้ด...</p>
            </div>
          )}

          {/* Categories */}
          <div className="bg-white px-4 py-3 border-b">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center px-3 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors !rounded-button ${
                    selectedCategory === category.id
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <i className={`${category.icon} mr-1 text-sm`}></i>
                  {category.name}
                </button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <div className="bg-white px-4 py-4">
            <div className="grid grid-cols-2 gap-3">
              {filteredProducts.map((product) => (
                <button
                  key={product.id}
                  onClick={() => addToCart(product)}
                  disabled={product.stock <= 0}
                  className={`bg-white border border-gray-200 rounded-xl p-3 hover:shadow-md transition-shadow text-left ${
                    product.stock <= 0 ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <div className="w-full h-20 rounded-lg overflow-hidden mb-2">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    {product.stock <= 0 && (
                      <div className="absolute inset-0 bg-red-500 bg-opacity-75 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">หมด</span>
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium text-gray-800 text-sm mb-1 truncate">
                    {product.name}
                  </h3>
                  <p className="text-blue-600 font-bold text-sm mb-1">
                    ฿{product.price}
                  </p>
                  <p className={`text-xs ${product.stock <= 10 ? 'text-red-500' : 'text-gray-500'}`}>
                    คงเหลือ: {product.stock}
                    {product.stock <= 10 && <span className="ml-1">⚠️</span>}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Cart Summary - Fixed Bottom */}
          {cart.length > 0 && (
            <div className="fixed bottom-20 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
              <div className="max-w-sm mx-auto p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-800">รายการสั่งซื้อ ({cart.length})</h3>
                  <button
                    onClick={clearCart}
                    className="text-red-500 text-sm hover:text-red-700"
                  >
                    ล้างทั้งหมด
                  </button>
                </div>
                
                <div className="space-y-2 mb-4 max-h-32 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={item.id} className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-800 text-sm">{item.name}</h4>
                        <p className="text-gray-500 text-xs">฿{item.price} x {item.quantity}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center !rounded-button"
                        >
                          <i className="ri-subtract-line text-xs"></i>
                        </button>
                        <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                        <button
                          onClick={() => addToCart(item)}
                          className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center !rounded-button"
                        >
                          <i className="ri-add-line text-xs"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-3">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-lg font-bold text-gray-800">รวม</span>
                    <span className="text-lg font-bold text-blue-600">฿{total.toLocaleString()}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Link
                      href="/pos/payment"
                      className="bg-green-500 text-white py-3 px-4 rounded-xl font-medium text-center hover:bg-green-600 transition-colors !rounded-button"
                    >
                      ชำระเงิน
                    </Link>
                    <button
                      onClick={() => {
                        localStorage.setItem('pos_cart', JSON.stringify(cart));
                        localStorage.setItem('pos_total', total.toString());
                        clearCart();
                      }}
                      className="bg-gray-500 text-white py-3 px-4 rounded-xl font-medium text-center hover:bg-gray-600 transition-colors !rounded-button"
                    >
                      พักบิล
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Empty Cart Message */}
          {cart.length === 0 && (
            <div className="text-center py-8">
              <i className="ri-shopping-cart-line text-gray-400 text-4xl mb-4"></i>
              <p className="text-gray-500">เพิ่มสินค้าลงตะกร้าเพื่อเริ่มการขาย</p>
            </div>
          )}

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}
