'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function CustomersPage() {
  const [activeTab, setActiveTab] = useState('customers');
  const [searchTerm, setSearchTerm] = useState('');

  const customers = [
    {
      id: 1,
      name: 'คุณสมชาย ใจดี',
      phone: '08-1234-5678',
      email: 'somchai@email.com',
      points: 450,
      tier: 'Gold',
      totalSpent: 12500,
      lastVisit: '2025-01-15',
      joinDate: '2024-03-15'
    },
    {
      id: 2,
      name: 'คุณสมหญิง รักดี',
      phone: '08-9876-5432',
      email: 'somying@email.com',
      points: 280,
      tier: 'Silver',
      totalSpent: 8900,
      lastVisit: '2025-01-14',
      joinDate: '2024-06-20'
    },
    {
      id: 3,
      name: 'คุณวิชัย สุขใจ',
      phone: '08-5555-6666',
      email: 'wichai@email.com',
      points: 150,
      tier: 'Bronze',
      totalSpent: 4200,
      lastVisit: '2025-01-13',
      joinDate: '2024-09-10'
    },
    {
      id: 4,
      name: 'คุณนิดา ขยัน',
      phone: '08-7777-8888',
      email: 'nida@email.com',
      points: 720,
      tier: 'Platinum',
      totalSpent: 25600,
      lastVisit: '2025-01-12',
      joinDate: '2024-01-05'
    }
  ];

  const membershipTiers = [
    {
      name: 'Bronze',
      minSpent: 0,
      benefits: ['แต้มสะสม 1%', 'ข้อเสนอพิเศษ'],
      color: 'bg-orange-100 text-orange-600',
      count: 45
    },
    {
      name: 'Silver',
      minSpent: 5000,
      benefits: ['แต้มสะสม 2%', 'ส่วนลด 5%', 'ข้อเสนอพิเศษ'],
      color: 'bg-gray-100 text-gray-600',
      count: 28
    },
    {
      name: 'Gold',
      minSpent: 10000,
      benefits: ['แต้มสะสม 3%', 'ส่วนลด 10%', 'ของแถม'],
      color: 'bg-yellow-100 text-yellow-600',
      count: 15
    },
    {
      name: 'Platinum',
      minSpent: 20000,
      benefits: ['แต้มสะสม 5%', 'ส่วนลด 15%', 'บริการพิเศษ'],
      color: 'bg-purple-100 text-purple-600',
      count: 8
    }
  ];

  const promotions = [
    {
      id: 1,
      title: 'ลูกค้า Gold ลด 20%',
      description: 'สำหรับเครื่องดื่มทุกเมนู',
      validUntil: '2025-01-31',
      tier: 'Gold',
      active: true
    },
    {
      id: 2,
      title: 'แต้มสะสมคูณ 2',
      description: 'ซื้อครบ 300 บาท',
      validUntil: '2025-02-15',
      tier: 'All',
      active: true
    },
    {
      id: 3,
      title: 'ของแถมพิเศษ',
      description: 'ซื้อ 2 แถม 1 สำหรับสมาชิก Platinum',
      validUntil: '2025-01-25',
      tier: 'Platinum',
      active: true
    }
  ];

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTierColor = (tier) => {
    switch(tier) {
      case 'Bronze': return 'bg-orange-100 text-orange-600';
      case 'Silver': return 'bg-gray-100 text-gray-600';
      case 'Gold': return 'bg-yellow-100 text-yellow-600';
      case 'Platinum': return 'bg-purple-100 text-purple-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {/* Header */}
          <div className="bg-white px-4 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-gray-800">ลูกค้า & สมาชิก</h1>
              <Link
                href="/pos/customers/add"
                className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center !rounded-button"
              >
                <i className="ri-user-add-line"></i>
              </Link>
            </div>
          </div>

          {/* Search */}
          <div className="bg-white px-4 py-3 border-b">
            <div className="relative">
              <input
                type="text"
                placeholder="ค้นหาลูกค้า..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-1">
            <div className="flex">
              <button
                onClick={() => setActiveTab('customers')}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors !rounded-button ${
                  activeTab === 'customers'
                    ? 'bg-blue-500 text-white'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                ลูกค้า
              </button>
              <button
                onClick={() => setActiveTab('tiers')}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors !rounded-button ${
                  activeTab === 'tiers'
                    ? 'bg-blue-500 text-white'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                ระดับสมาชิก
              </button>
              <button
                onClick={() => setActiveTab('promotions')}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors !rounded-button ${
                  activeTab === 'promotions'
                    ? 'bg-blue-500 text-white'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                โปรโมชั่น
              </button>
            </div>
          </div>

          {activeTab === 'customers' && (
            <div className="mx-4 mt-4 space-y-3">
              {filteredCustomers.map((customer) => (
                <div key={customer.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{customer.name}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTierColor(customer.tier)}`}>
                          {customer.tier}
                        </span>
                      </div>
                      <p className="text-gray-600 text-sm mb-1">{customer.phone}</p>
                      <p className="text-gray-600 text-sm mb-3">{customer.email}</p>
                      
                      <div className="grid grid-cols-3 gap-3 mb-3">
                        <div className="text-center">
                          <div className="text-lg font-bold text-blue-600">{customer.points}</div>
                          <div className="text-xs text-gray-500">แต้มสะสม</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-green-600">฿{customer.totalSpent.toLocaleString()}</div>
                          <div className="text-xs text-gray-500">ยอดซื้อรวม</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-purple-600">
                            {Math.floor((Date.now() - new Date(customer.lastVisit).getTime()) / (1000 * 60 * 60 * 24))}
                          </div>
                          <div className="text-xs text-gray-500">วันที่แล้ว</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">
                          เข้าร่วม: {new Date(customer.joinDate).toLocaleDateString('th-TH')}
                        </span>
                        <div className="flex items-center space-x-2">
                          <Link
                            href={`/pos/customers/edit/${customer.id}`}
                            className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center !rounded-button"
                          >
                            <i className="ri-edit-line text-sm"></i>
                          </Link>
                          <button className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center !rounded-button">
                            <i className="ri-phone-line text-sm"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'tiers' && (
            <div className="mx-4 mt-4 space-y-3">
              {membershipTiers.map((tier, index) => (
                <div key={index} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${tier.color}`}>
                        {tier.name}
                      </span>
                      <span className="ml-3 text-gray-600 text-sm">
                        {tier.count} คน
                      </span>
                    </div>
                    <span className="text-sm text-gray-500">
                      ซื้อขั้นต่ำ ฿{tier.minSpent.toLocaleString()}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {tier.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center">
                        <i className="ri-check-line text-green-500 mr-2 text-sm"></i>
                        <span className="text-sm text-gray-600">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'promotions' && (
            <div className="mx-4 mt-4 space-y-3">
              {promotions.map((promotion) => (
                <div key={promotion.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-gray-800">{promotion.title}</h3>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        promotion.active ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {promotion.active ? 'ใช้งาน' : 'หยุด'}
                      </span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{promotion.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <span className="text-xs text-gray-500">
                        สำหรับ: {promotion.tier}
                      </span>
                      <span className="text-xs text-gray-500">
                        ถึง: {new Date(promotion.validUntil).toLocaleDateString('th-TH')}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center !rounded-button">
                        <i className="ri-edit-line text-sm"></i>
                      </button>
                      <button className="w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center !rounded-button">
                        <i className="ri-delete-bin-line text-sm"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Quick Actions */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">การดำเนินการด่วน</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/pos/customers/add"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-user-add-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">เพิ่มลูกค้า</span>
              </Link>
              <Link
                href="/pos/customers/import"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-file-upload-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">นำเข้าข้อมูล</span>
              </Link>
              <Link
                href="/pos/customers/points"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-coin-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">จัดการแต้ม</span>
              </Link>
              <Link
                href="/pos/customers/report"
                className="flex items-center justify-center p-3 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors"
              >
                <i className="ri-bar-chart-line text-orange-600 mr-2"></i>
                <span className="text-sm font-medium text-orange-600">รายงาน</span>
              </Link>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}