'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const [selectedBranch, setSelectedBranch] = useState('all');

  const periods = [
    { id: 'today', name: 'วันนี้' },
    { id: 'week', name: 'สัปดาห์นี้' },
    { id: 'month', name: 'เดือนนี้' },
    { id: 'year', name: 'ปีนี้' }
  ];

  const branches = [
    { id: 'all', name: 'ทุกสาขา' },
    { id: 'branch1', name: 'สาขาสยาม' },
    { id: 'branch2', name: 'สาขาอโศก' },
    { id: 'branch3', name: 'สาขาชิดลม' }
  ];

  const salesData = {
    totalSales: 45600,
    totalOrders: 156,
    averageOrder: 292,
    profit: 18240,
    growth: 12.5
  };

  const topProducts = [
    { name: 'กาแฟอเมริกาโน', sold: 45, revenue: 2925, growth: 15 },
    { name: 'ข้าวผัดกุ้ง', sold: 32, revenue: 3840, growth: 8 },
    { name: 'ชาไทย', sold: 28, revenue: 1540, growth: -5 },
    { name: 'น้ำส้มคั้น', sold: 24, revenue: 1080, growth: 20 },
    { name: 'คุกกี้ช็อกโกแลต', sold: 22, revenue: 770, growth: 12 }
  ];

  const hourlyData = [
    { time: '08:00', sales: 1200, orders: 8 },
    { time: '09:00', sales: 2100, orders: 12 },
    { time: '10:00', sales: 3200, orders: 18 },
    { time: '11:00', sales: 4800, orders: 25 },
    { time: '12:00', sales: 6200, orders: 32 },
    { time: '13:00', sales: 5800, orders: 28 },
    { time: '14:00', sales: 3900, orders: 22 },
    { time: '15:00', sales: 4200, orders: 24 },
    { time: '16:00', sales: 3600, orders: 20 },
    { time: '17:00', sales: 2800, orders: 15 },
    { time: '18:00', sales: 2200, orders: 12 },
    { time: '19:00', sales: 1800, orders: 10 }
  ];

  const paymentMethods = [
    { method: 'เงินสด', amount: 18240, percentage: 40 },
    { method: 'QR Payment', amount: 15960, percentage: 35 },
    { method: 'บัตรเครดิต', amount: 9120, percentage: 20 },
    { method: 'E-Wallet', amount: 2280, percentage: 5 }
  ];

  const maxHourlyOrders = Math.max(...hourlyData.map(d => d.orders));

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {/* Header */}
          <div className="bg-white px-4 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-gray-800">รายงานการขาย</h1>
              <Link
                href="/pos/reports/export"
                className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center !rounded-button"
              >
                <i className="ri-download-line"></i>
              </Link>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white px-4 py-3 border-b">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ช่วงเวลา</label>
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                >
                  {periods.map(period => (
                    <option key={period.id} value={period.id}>{period.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">สาขา</label>
                <select
                  value={selectedBranch}
                  onChange={(e) => setSelectedBranch(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                >
                  {branches.map(branch => (
                    <option key={branch.id} value={branch.id}>{branch.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Sales Overview */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">ภาพรวมการขาย</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  ฿{salesData.totalSales.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500">ยอดขายรวม</div>
                <div className="text-xs text-green-600 mt-1">+{salesData.growth}%</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {salesData.totalOrders}
                </div>
                <div className="text-sm text-gray-500">ยอดออร์เดอร์</div>
                <div className="text-xs text-gray-500 mt-1">฿{salesData.averageOrder}/ออร์เดอร์</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  ฿{salesData.profit.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500">กำไรสุทธิ</div>
                <div className="text-xs text-purple-600 mt-1">
                  {Math.round((salesData.profit / salesData.totalSales) * 100)}%
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  ฿{salesData.averageOrder}
                </div>
                <div className="text-sm text-gray-500">ออร์เดอร์เฉลี่ย</div>
                <div className="text-xs text-orange-600 mt-1">
                  {Math.round(salesData.totalSales / salesData.totalOrders)}
                </div>
              </div>
            </div>
          </div>

          {/* Hourly Sales Chart */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">ยอดขายแต่ละชั่วโมง</h3>
            <div className="space-y-2">
              {hourlyData.map((data, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-12 text-xs text-gray-500">{data.time}</div>
                  <div className="flex-1 mx-2">
                    <div className="bg-gray-100 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{
                          width: `${(data.orders / maxHourlyOrders) * 100}%`
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="w-16 text-right text-xs text-gray-600">
                    {data.orders} ออร์เดอร์
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Products */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">สินค้าขายดี</h3>
            <div className="space-y-3">
              {topProducts.map((product, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mr-3">
                      <span className="text-sm font-bold">{index + 1}</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 text-sm">{product.name}</h4>
                      <p className="text-gray-500 text-xs">ขายได้ {product.sold} ชิ้น</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-800 text-sm">
                      ฿{product.revenue.toLocaleString()}
                    </div>
                    <div className={`text-xs ${
                      product.growth > 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {product.growth > 0 ? '+' : ''}{product.growth}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">วิธีการชำระเงิน</h3>
            <div className="space-y-3">
              {paymentMethods.map((method, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                      <i className={`${
                        method.method === 'เงินสด' ? 'ri-money-dollar-circle-line' :
                        method.method === 'QR Payment' ? 'ri-qr-code-line' :
                        method.method === 'บัตรเครดิต' ? 'ri-bank-card-line' :
                        'ri-wallet-line'
                      } text-sm text-gray-600`}></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 text-sm">{method.method}</h4>
                      <div className="w-24 bg-gray-100 rounded-full h-1 mt-1">
                        <div
                          className="bg-blue-500 h-1 rounded-full"
                          style={{ width: `${method.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-800 text-sm">
                      ฿{method.amount.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500">
                      {method.percentage}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">รายงานอื่นๆ</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/pos/reports/inventory"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-archive-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">รายงานสต๊อก</span>
              </Link>
              <Link
                href="/pos/reports/customer"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-user-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">รายงานลูกค้า</span>
              </Link>
              <Link
                href="/pos/reports/profit"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-money-dollar-circle-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">รายงานกำไร</span>
              </Link>
              <Link
                href="/pos/reports/tax"
                className="flex items-center justify-center p-3 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors"
              >
                <i className="ri-file-text-line text-orange-600 mr-2"></i>
                <span className="text-sm font-medium text-orange-600">รายงานภาษี</span>
              </Link>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}