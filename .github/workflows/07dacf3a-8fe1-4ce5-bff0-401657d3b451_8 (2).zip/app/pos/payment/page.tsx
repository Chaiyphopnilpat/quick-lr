
'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function PaymentPage() {
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [cashReceived, setCashReceived] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [qrPaymentStatus, setQrPaymentStatus] = useState('waiting');
  const [cart, setCart] = useState([]);
  const [printing, setPrinting] = useState(false);

  const orderTotal = 320;
  const tax = Math.round(orderTotal * 0.07 * 100) / 100;
  const grandTotal = orderTotal + tax;
  const change = cashReceived ? Math.max(0, parseFloat(cashReceived) - grandTotal) : 0;

  // โหลดข้อมูลจาก localStorage
  useEffect(() => {
    const savedCart = localStorage.getItem('pos_cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const paymentMethods = [
    { id: 'cash', name: 'เงินสด', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
    { id: 'qr', name: 'QR Payment', icon: 'ri-qr-code-line', color: 'bg-blue-500' },
    { id: 'card', name: 'บัตรเครดิต/เดบิต', icon: 'ri-bank-card-line', color: 'bg-purple-500' },
    { id: 'wallet', name: 'E-Wallet', icon: 'ri-wallet-line', color: 'bg-orange-500' }
  ];

  const quickCashAmounts = [
    { amount: 400, label: '400' },
    { amount: 500, label: '500' },
    { amount: 1000, label: '1,000' },
    { amount: Math.ceil(grandTotal), label: 'พอดี' }
  ];

  const eWallets = [
    { id: 'truemoney', name: 'TrueMoney', icon: 'ri-wallet-line', color: 'bg-red-500' },
    { id: 'promptpay', name: 'PromptPay', icon: 'ri-qr-code-line', color: 'bg-blue-500' },
    { id: 'rabbit', name: 'Rabbit LINE Pay', icon: 'ri-rabbit-line', color: 'bg-green-500' },
    { id: 'shopee', name: 'ShopeePay', icon: 'ri-shopping-bag-line', color: 'bg-orange-500' }
  ];

  const handlePayment = () => {
    if (paymentMethod === 'cash' && (!cashReceived || parseFloat(cashReceived) < grandTotal)) {
      alert('กรุณาระบุจำนวนเงินที่ถูกต้อง');
      return;
    }
    
    if (paymentMethod === 'card' && !cardNumber) {
      alert('กรุณากรอกหมายเลขบัตร');
      return;
    }

    // จำลองการประมวลผลการชำระเงิน
    if (paymentMethod === 'qr' || paymentMethod === 'wallet') {
      setQrPaymentStatus('processing');
      setTimeout(() => {
        setQrPaymentStatus('success');
        setTimeout(() => {
          setShowReceipt(true);
        }, 1000);
      }, 2000);
    } else {
      setShowReceipt(true);
    }
  };

  const handlePrint = () => {
    setPrinting(true);
    setTimeout(() => {
      window.print();
      setPrinting(false);
    }, 1000);
  };

  const handleNewSale = () => {
    localStorage.removeItem('pos_cart');
    localStorage.removeItem('pos_total');
    setCart([]);
    setShowReceipt(false);
  };

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {!showReceipt ? (
            <>
              {/* Header */}
              <div className="bg-white px-4 py-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <Link href="/pos" className="text-gray-600">
                    <i className="ri-arrow-left-line text-xl"></i>
                  </Link>
                  <h1 className="text-xl font-bold text-gray-800">ชำระเงิน</h1>
                  <div className="text-sm text-gray-500">
                    {new Date().toLocaleTimeString('th-TH', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3">สรุปคำสั่งซื้อ</h3>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">ยอดรวม</span>
                    <span className="font-medium">฿{orderTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">ภาษี (7%)</span>
                    <span className="font-medium">฿{tax.toLocaleString()}</span>
                  </div>
                  <div className="border-t pt-2">
                    <div className="flex justify-between">
                      <span className="font-bold text-gray-800">ยอดรวมสุทธิ</span>
                      <span className="font-bold text-blue-600 text-lg">฿{grandTotal.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3">วิธีการชำระเงิน</h3>
                <div className="grid grid-cols-2 gap-3">
                  {paymentMethods.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id)}
                      className={`flex items-center p-3 rounded-xl transition-all ${
                        paymentMethod === method.id
                          ? 'bg-blue-50 border-2 border-blue-500'
                          : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                      }`}
                    >
                      <div className={`w-8 h-8 ${method.color} rounded-full flex items-center justify-center mr-3`}>
                        <i className={`${method.icon} text-white text-sm`}></i>
                      </div>
                      <span className="font-medium text-gray-800 text-sm">{method.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Cash Payment */}
              {paymentMethod === 'cash' && (
                <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-gray-800 mb-3">รับเงินสด</h3>
                  <div className="mb-4">
                    <input
                      type="number"
                      placeholder="จำนวนเงินที่รับ"
                      value={cashReceived}
                      onChange={(e) => setCashReceived(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg text-center"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    {quickCashAmounts.map((item) => (
                      <button
                        key={item.amount}
                        onClick={() => setCashReceived(item.amount.toString())}
                        className="bg-gray-100 hover:bg-gray-200 py-2 px-4 rounded-lg text-gray-700 font-medium transition-colors !rounded-button"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                  {change > 0 && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                      <div className="flex justify-between">
                        <span className="text-green-700 font-medium">เงินทอน</span>
                        <span className="font-bold text-green-700 text-lg">฿{change.toLocaleString()}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Card Payment */}
              {paymentMethod === 'card' && (
                <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-gray-800 mb-3">บัตรเครดิต/เดบิต</h3>
                  <div className="mb-4">
                    <input
                      type="text"
                      placeholder="หมายเลขบัตร (4 หลักสุดท้าย)"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      maxLength={4}
                      className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-lg"
                    />
                  </div>
                  <div className="flex items-center justify-center space-x-4 mb-4">
                    <img src="https://readdy.ai/api/search-image?query=visa%20card%20logo%2C%20payment%20logo%2C%20credit%20card%20brand&width=40&height=25&seq=visa-logo&orientation=landscape" alt="Visa" className="h-6" />
                    <img src="https://readdy.ai/api/search-image?query=mastercard%20logo%2C%20payment%20logo%2C%20credit%20card%20brand&width=40&height=25&seq=mastercard-logo&orientation=landscape" alt="MasterCard" className="h-6" />
                    <img src="https://readdy.ai/api/search-image?query=jcb%20card%20logo%2C%20payment%20logo%2C%20credit%20card%20brand&width=40&height=25&seq=jcb-logo&orientation=landscape" alt="JCB" className="h-6" />
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <p className="text-blue-700 text-sm">
                      <i className="ri-information-line mr-1"></i>
                      กรุณาใส่บัตรใน EDC Terminal หรือแตะเพื่อชำระ
                    </p>
                  </div>
                </div>
              )}

              {/* QR Payment */}
              {paymentMethod === 'qr' && (
                <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm text-center">
                  <h3 className="font-semibold text-gray-800 mb-3">QR Code สำหรับชำระเงิน</h3>
                  <div className="w-48 h-48 bg-gray-100 rounded-xl mx-auto mb-4 flex items-center justify-center relative">
                    {qrPaymentStatus === 'waiting' && (
                      <div className="text-center">
                        <i className="ri-qr-code-line text-6xl text-gray-400 mb-2"></i>
                        <p className="text-gray-500 text-sm">QR Code สำหรับชำระเงิน</p>
                      </div>
                    )}
                    {qrPaymentStatus === 'processing' && (
                      <div className="text-center">
                        <i className="ri-loader-line text-4xl text-blue-500 mb-2 animate-spin"></i>
                        <p className="text-blue-600 text-sm">กำลังประมวลผล...</p>
                      </div>
                    )}
                    {qrPaymentStatus === 'success' && (
                      <div className="text-center">
                        <i className="ri-check-line text-4xl text-green-500 mb-2"></i>
                        <p className="text-green-600 text-sm">ชำระเงินสำเร็จ</p>
                      </div>
                    )}
                  </div>
                  <p className="text-gray-600 text-sm mb-4">ยอดชำระ: ฿{grandTotal.toLocaleString()}</p>
                  <div className="flex items-center justify-center space-x-4">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <i className="ri-qr-code-line text-white text-sm"></i>
                    </div>
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                      <i className="ri-wallet-line text-white text-sm"></i>
                    </div>
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <i className="ri-smartphone-line text-white text-sm"></i>
                    </div>
                  </div>
                </div>
              )}

              {/* E-Wallet Payment */}
              {paymentMethod === 'wallet' && (
                <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-gray-800 mb-3">เลือก E-Wallet</h3>
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    {eWallets.map((wallet) => (
                      <button
                        key={wallet.id}
                        className={`flex items-center p-3 rounded-xl transition-all bg-gray-50 border-2 border-transparent hover:bg-gray-100`}
                      >
                        <div className={`w-8 h-8 ${wallet.color} rounded-full flex items-center justify-center mr-3`}>
                          <i className={`${wallet.icon} text-white text-sm`}></i>
                        </div>
                        <span className="font-medium text-gray-800 text-sm">{wallet.name}</span>
                      </button>
                    ))}
                  </div>
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <p className="text-orange-700 text-sm">
                      <i className="ri-smartphone-line mr-1"></i>
                      ลูกค้าสามารถสแกน QR Code ด้วยแอปพลิเคชันที่เลือก
                    </p>
                  </div>
                </div>
              )}

              {/* Complete Payment Button */}
              <div className="px-4 mt-6">
                <button
                  onClick={handlePayment}
                  disabled={
                    (paymentMethod === 'cash' && (!cashReceived || parseFloat(cashReceived) < grandTotal)) ||
                    (paymentMethod === 'card' && !cardNumber) ||
                    qrPaymentStatus === 'processing'
                  }
                  className="w-full bg-green-500 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed !rounded-button"
                >
                  {qrPaymentStatus === 'processing' ? 'กำลังประมวลผล...' : 'ชำระเงิน'}
                </button>
              </div>
            </>
          ) : (
            /* Receipt */
            <div className="bg-white mx-4 mt-4 rounded-xl p-6 shadow-sm">
              <div className="text-center border-b pb-4 mb-4">
                <h2 className="text-xl font-bold text-gray-800 mb-2">ร้าน My Restaurant</h2>
                <p className="text-gray-600 text-sm">123 ถนนสุขุมวิท กรุงเทพฯ 10110</p>
                <p className="text-gray-600 text-sm">โทร: 02-123-4567</p>
                <p className="text-gray-600 text-sm">Tax ID: 1234567890123</p>
              </div>

              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span>วันที่:</span>
                  <span suppressHydrationWarning={true}>
                    {new Date().toLocaleDateString('th-TH')}
                  </span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span>เวลา:</span>
                  <span suppressHydrationWarning={true}>
                    {new Date().toLocaleTimeString('th-TH')}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>ใบเสร็จเลขที่:</span>
                  <span>RC-{Date.now().toString().slice(-6)}</span>
                </div>
              </div>

              <div className="border-t border-b py-4 mb-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">กาแฟอเมริกาโน x2</span>
                    <span>฿130</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">ข้าวผัดกุ้ง x1</span>
                    <span>฿120</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">ชาไทย x1</span>
                    <span>฿55</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">คุกกี้ช็อกโกแลต x1</span>
                    <span>฿35</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">ยอดรวม</span>
                  <span>฿{orderTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">ภาษี (7%)</span>
                  <span>฿{tax.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-lg">
                  <span>ยอดรวมสุทธิ</span>
                  <span>฿{grandTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    วิธีชำระ: {paymentMethods.find(p => p.id === paymentMethod)?.name}
                  </span>
                  <span>฿{grandTotal.toLocaleString()}</span>
                </div>
                {paymentMethod === 'cash' && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-gray-600">เงินสด</span>
                      <span>฿{parseFloat(cashReceived).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">เงินทอน</span>
                      <span>฿{change.toLocaleString()}</span>
                    </div>
                  </>
                )}
              </div>

              <div className="text-center mb-6">
                <p className="text-gray-600 text-sm">ขอบคุณที่ใช้บริการ</p>
                <p className="text-gray-600 text-sm">โทร 02-123-4567 สำหรับข้อสงสัย</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handlePrint}
                  disabled={printing}
                  className="bg-blue-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-600 transition-colors disabled:bg-gray-300 !rounded-button"
                >
                  <i className={`${printing ? 'ri-loader-line animate-spin' : 'ri-printer-line'} mr-2`}></i>
                  {printing ? 'กำลังพิมพ์...' : 'พิมพ์ใบเสร็จ'}
                </button>
                <button
                  onClick={handleNewSale}
                  className="bg-green-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-green-600 transition-colors !rounded-button"
                >
                  <i className="ri-add-line mr-2"></i>
                  ขายใหม่
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}
