'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function ProfilePage() {
  const [user, setUser] = useState({
    name: 'สมชาย ใจดี',
    email: 'somchai@example.com',
    phone: '08-1234-5678',
    memberSince: '2024',
    plan: 'Premium'
  });

  const stats = [
    {
      title: 'โครงการ',
      value: '24',
      icon: 'ri-folder-line',
      color: 'text-blue-600'
    },
    {
      title: 'เครดิต',
      value: '150',
      icon: 'ri-coin-line',
      color: 'text-green-600'
    },
    {
      title: 'คะแนน',
      value: '1,250',
      icon: 'ri-award-line',
      color: 'text-purple-600'
    }
  ];

  const menuItems = [
    {
      title: 'แก้ไขโปรไฟล์',
      icon: 'ri-edit-line',
      href: '/profile/edit',
      color: 'text-blue-600'
    },
    {
      title: 'การตั้งค่า',
      icon: 'ri-settings-line',
      href: '/profile/settings',
      color: 'text-gray-600'
    },
    {
      title: 'ความช่วยเหลือ',
      icon: 'ri-question-line',
      href: '/profile/help',
      color: 'text-green-600'
    },
    {
      title: 'เงื่อนไขการใช้งาน',
      icon: 'ri-file-text-line',
      href: '/profile/terms',
      color: 'text-gray-600'
    },
    {
      title: 'ออกจากระบบ',
      icon: 'ri-logout-box-line',
      href: '/auth/logout',
      color: 'text-red-600'
    }
  ];

  const achievements = [
    {
      title: 'ผู้ใช้งานใหม่',
      description: 'ยินดีต้อนรับสู่ AI Platform',
      icon: 'ri-user-add-line',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      title: 'นักสร้างสรรค์',
      description: 'สร้างรูปภาพ 10 ชิ้นแล้ว',
      icon: 'ri-image-line',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      title: 'ผู้สำรวจ',
      description: 'ใช้เครื่องมือครบทุกประเภท',
      icon: 'ri-compass-line',
      color: 'bg-green-100 text-green-600'
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Profile Header */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              <div className="flex-1">
                <h2 className="font-bold text-gray-800 text-lg">{user.name}</h2>
                <p className="text-gray-600 text-sm">{user.email}</p>
                <div className="flex items-center mt-1">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                    {user.plan}
                  </span>
                  <span className="text-gray-500 text-xs ml-2">
                    สมาชิกตั้งแต่ {user.memberSince}
                  </span>
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className={`w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center mx-auto mb-1`}>
                    <i className={`${stat.icon} ${stat.color} text-sm`}></i>
                  </div>
                  <div className="text-lg font-bold text-gray-800">{stat.value}</div>
                  <div className="text-xs text-gray-500">{stat.title}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Menu Items */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">เมนู</h3>
            <div className="space-y-3">
              {menuItems.map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-colors"
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                      <i className={`${item.icon} ${item.color} text-sm`}></i>
                    </div>
                    <span className="font-medium text-gray-800 text-sm">{item.title}</span>
                  </div>
                  <i className="ri-arrow-right-s-line text-gray-400"></i>
                </Link>
              ))}
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">ความสำเร็จ</h3>
            <div className="space-y-3">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full ${achievement.color} flex items-center justify-center mr-3`}>
                    <i className={`${achievement.icon} text-sm`}></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800 text-sm">{achievement.title}</h4>
                    <p className="text-gray-500 text-xs">{achievement.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">กิจกรรมล่าสุด</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mr-3 mt-1">
                  <i className="ri-image-line text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-800 text-sm">สร้างรูปภาพ AI</h4>
                    <span className="text-xs text-gray-500">2 ชั่วโมงที่แล้ว</span>
                  </div>
                  <p className="text-gray-600 text-xs mt-1">โลโก้บริษัทใหม่</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center mr-3 mt-1">
                  <i className="ri-wallet-line text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-800 text-sm">เติมเครดิต</h4>
                    <span className="text-xs text-gray-500">1 วันที่แล้ว</span>
                  </div>
                  <p className="text-gray-600 text-xs mt-1">+100 เครดิต</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mr-3 mt-1">
                  <i className="ri-file-text-line text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-800 text-sm">วิเคราะห์ข้อความ</h4>
                    <span className="text-xs text-gray-500">2 วันที่แล้ว</span>
                  </div>
                  <p className="text-gray-600 text-xs mt-1">เอกสารธุรกิจ</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}