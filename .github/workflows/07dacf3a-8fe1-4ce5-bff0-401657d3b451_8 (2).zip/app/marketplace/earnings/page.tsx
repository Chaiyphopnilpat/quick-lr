'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function EarningsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const periods = [
    { id: 'week', name: 'สัปดาห์นี้' },
    { id: 'month', name: 'เดือนนี้' },
    { id: 'quarter', name: 'ไตรมาสนี้' },
    { id: 'year', name: 'ปีนี้' }
  ];

  const filters = [
    { id: 'all', name: 'ทั้งหมด' },
    { id: 'products', name: 'ขายสินค้า' },
    { id: 'services', name: 'บริการ' },
    { id: 'referral', name: 'แนะนำเพื่อน' }
  ];

  const earningsData = {
    totalEarnings: 45800,
    pendingPayment: 12500,
    completedOrders: 156,
    growth: 18.5,
    commission: 3250
  };

  const earningsHistory = [
    {
      id: 1,
      type: 'ขายสินค้า',
      product: 'เสื้อยืดแฟชั่น',
      amount: 450,
      commission: 45,
      netAmount: 405,
      date: '2025-01-15',
      status: 'paid',
      orderId: 'ORD-2025-001'
    },
    {
      id: 2,
      type: 'บริการ',
      product: 'ออกแบบโลโก้',
      amount: 1200,
      commission: 120,
      netAmount: 1080,
      date: '2025-01-14',
      status: 'pending',
      orderId: 'SRV-2025-001'
    },
    {
      id: 3,
      type: 'ขายสินค้า',
      product: 'กระเป๋าสะพาย',
      amount: 850,
      commission: 85,
      netAmount: 765,
      date: '2025-01-13',
      status: 'paid',
      orderId: 'ORD-2025-002'
    },
    {
      id: 4,
      type: 'แนะนำเพื่อน',
      product: 'โบนัสแนะนำ',
      amount: 200,
      commission: 0,
      netAmount: 200,
      date: '2025-01-12',
      status: 'paid',
      orderId: 'REF-2025-001'
    },
    {
      id: 5,
      type: 'ขายสินค้า',
      product: 'รองเท้าผ้าใบ',
      amount: 1500,
      commission: 150,
      netAmount: 1350,
      date: '2025-01-11',
      status: 'processing',
      orderId: 'ORD-2025-003'
    }
  ];

  const filteredEarnings = selectedFilter === 'all' 
    ? earningsHistory 
    : earningsHistory.filter(item => {
        if (selectedFilter === 'products') return item.type === 'ขายสินค้า';
        if (selectedFilter === 'services') return item.type === 'บริการ';
        if (selectedFilter === 'referral') return item.type === 'แนะนำเพื่อน';
        return true;
      });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'text-green-600 bg-green-50';
      case 'pending': return 'text-yellow-600 bg-yellow-50';
      case 'processing': return 'text-blue-600 bg-blue-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid': return 'จ่ายแล้ว';
      case 'pending': return 'รอจ่าย';
      case 'processing': return 'กำลังดำเนินการ';
      default: return 'ไม่ทราบ';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'ขายสินค้า': return 'ri-shopping-bag-line';
      case 'บริการ': return 'ri-service-line';
      case 'แนะนำเพื่อน': return 'ri-user-add-line';
      default: return 'ri-money-dollar-circle-line';
    }
  };

  const totalPaid = filteredEarnings
    .filter(item => item.status === 'paid')
    .reduce((sum, item) => sum + item.netAmount, 0);

  const totalPending = filteredEarnings
    .filter(item => item.status === 'pending')
    .reduce((sum, item) => sum + item.netAmount, 0);

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gray-100 pt-20 pb-24">
        <div className="max-w-sm mx-auto">
          
          {/* Header */}
          <div className="bg-white px-4 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <Link href="/marketplace" className="text-gray-600">
                <i className="ri-arrow-left-line text-xl"></i>
              </Link>
              <h1 className="text-xl font-bold text-gray-800">รายได้</h1>
              <Link
                href="/marketplace/earnings/withdraw"
                className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center !rounded-button"
              >
                <i className="ri-bank-card-line"></i>
              </Link>
            </div>
          </div>

          {/* Earnings Overview */}
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 mx-4 mt-4 rounded-2xl p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-green-100 text-sm">รายได้รวม</p>
                <p className="text-3xl font-bold">฿{earningsData.totalEarnings.toLocaleString()}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <i className="ri-money-dollar-circle-line text-3xl"></i>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-green-100 text-xs">รอรับเงิน</p>
                <p className="text-lg font-bold">฿{earningsData.pendingPayment.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-green-100 text-xs">ออร์เดอร์สำเร็จ</p>
                <p className="text-lg font-bold">{earningsData.completedOrders}</p>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-green-100 text-sm">เติบโต +{earningsData.growth}%</span>
              <div className="flex items-center text-green-100 text-sm">
                <i className="ri-trending-up-line mr-1"></i>
                <span>เทียบเดือนที่แล้ว</span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3 mx-4 mt-4">
            <div className="bg-white rounded-xl p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-blue-600">฿{totalPaid.toLocaleString()}</div>
              <div className="text-xs text-gray-500">จ่ายแล้ว</div>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-yellow-600">฿{totalPending.toLocaleString()}</div>
              <div className="text-xs text-gray-500">รอจ่าย</div>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-purple-600">฿{earningsData.commission.toLocaleString()}</div>
              <div className="text-xs text-gray-500">ค่าคอมมิชชั่น</div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ช่วงเวลา</label>
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                >
                  {periods.map(period => (
                    <option key={period.id} value={period.id}>{period.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ประเภท</label>
                <select
                  value={selectedFilter}
                  onChange={(e) => setSelectedFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                >
                  {filters.map(filter => (
                    <option key={filter.id} value={filter.id}>{filter.name}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setSelectedFilter(filter.id)}
                  className={`flex items-center px-3 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors !rounded-button ${
                    selectedFilter === filter.id
                      ? 'bg-green-500 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter.name}
                </button>
              ))}
            </div>
          </div>

          {/* Earnings Chart */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">กราฟรายได้</h3>
            <div className="relative w-full h-40 mb-4 rounded-lg overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=financial%20earnings%20chart%20graph%2C%20revenue%20analytics%20dashboard%2C%20green%20and%20blue%20gradient%20chart%2C%20business%20growth%20visualization%2C%20professional%20financial%20report%2C%20clean%20modern%20design%2C%20upward%20trending%20line%20graph&width=300&height=160&seq=earnings-chart&orientation=landscape"
                alt="Earnings Chart"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div>
                <div className="text-gray-500">สัปดาห์ 1</div>
                <div className="font-bold text-green-600">฿8,500</div>
              </div>
              <div>
                <div className="text-gray-500">สัปดาห์ 2</div>
                <div className="font-bold text-green-600">฿12,300</div>
              </div>
              <div>
                <div className="text-gray-500">สัปดาห์ 3</div>
                <div className="font-bold text-green-600">฿15,800</div>
              </div>
              <div>
                <div className="text-gray-500">สัปดาห์ 4</div>
                <div className="font-bold text-green-600">฿9,200</div>
              </div>
            </div>
          </div>

          {/* Earnings History */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">ประวัติรายได้</h3>
              <span className="text-sm text-gray-500">({filteredEarnings.length} รายการ)</span>
            </div>
            <div className="space-y-3">
              {filteredEarnings.map((earning) => (
                <div key={earning.id} className="border border-gray-200 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                        <i className={`${getTypeIcon(earning.type)} text-gray-600`}></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800 text-sm">{earning.product}</h4>
                        <p className="text-gray-500 text-xs">{earning.type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600 text-sm">
                        +฿{earning.netAmount.toLocaleString()}
                      </div>
                      <div className={`text-xs px-2 py-1 rounded-full ${getStatusColor(earning.status)}`}>
                        {getStatusText(earning.status)}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 space-y-1">
                    <div className="flex justify-between">
                      <span>ยอดขาย:</span>
                      <span>฿{earning.amount.toLocaleString()}</span>
                    </div>
                    {earning.commission > 0 && (
                      <div className="flex justify-between">
                        <span>ค่าคอมมิชชั่น:</span>
                        <span className="text-red-600">-฿{earning.commission.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>รหัสคำสั่งซื้อ:</span>
                      <span className="font-medium">{earning.orderId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>วันที่:</span>
                      <span>{new Date(earning.date).toLocaleDateString('th-TH')}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white mx-4 mt-4 rounded-xl p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">การดำเนินการ</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/marketplace/earnings/withdraw"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-bank-card-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">ถอนเงิน</span>
              </Link>
              <Link
                href="/marketplace/earnings/history"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-file-list-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">ประวัติรายละเอียด</span>
              </Link>
              <Link
                href="/marketplace/earnings/analytics"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-bar-chart-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">วิเคราะห์รายได้</span>
              </Link>
              <Link
                href="/marketplace/earnings/tax"
                className="flex items-center justify-center p-3 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors"
              >
                <i className="ri-file-text-line text-orange-600 mr-2"></i>
                <span className="text-sm font-medium text-orange-600">รายงานภาษี</span>
              </Link>
            </div>
          </div>

          {/* Tips */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 mx-4 mt-4 rounded-2xl p-4 text-white">
            <div className="flex items-center mb-3">
              <i className="ri-lightbulb-line text-2xl mr-3"></i>
              <h3 className="font-semibold">เคล็ดลับเพิ่มรายได้</h3>
            </div>
            <div className="space-y-2 text-sm">
              <p>• อัปเดตสินค้าใหม่ๆ เป็นประจำ</p>
              <p>• ตอบข้อความลูกค้าอย่างรวดเร็ว</p>
              <p>• เพิ่มรูปภาพสินค้าที่สวยงาม</p>
              <p>• ใช้โปรโมชั่นและส่วนลดอย่างเหมาะสม</p>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}