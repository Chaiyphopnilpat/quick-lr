'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function MarketplacePage() {
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'ทั้งหมด', icon: 'ri-apps-line' },
    { id: 'models', name: 'โมเดล AI', icon: 'ri-brain-line' },
    { id: 'tools', name: 'เครื่องมือ', icon: 'ri-tools-line' },
    { id: 'datasets', name: 'ชุดข้อมูล', icon: 'ri-database-line' },
    { id: 'templates', name: 'แม่แบบ', icon: 'ri-file-copy-line' }
  ];

  const products = [
    {
      id: 1,
      title: 'GPT-4 Vision Model',
      description: 'โมเดล AI สำหรับวิเคราะห์รูปภาพ',
      price: '฿1,299',
      rating: 4.9,
      reviews: 234,
      category: 'models',
      image: 'https://readdy.ai/api/search-image?query=futuristic%20AI%20brain%20model%20with%20neural%20networks%2C%20holographic%20display%2C%20cyberpunk%20aesthetic%2C%20blue%20and%20purple%20glow%2C%20digital%20interface%2C%20machine%20learning%20visualization%2C%20high-tech%20concept%20art&width=150&height=150&seq=ai-model-1&orientation=squarish'
    },
    {
      id: 2,
      title: 'Image Generator Pro',
      description: 'เครื่องมือสร้างรูปภาพคุณภาพสูง',
      price: '฿899',
      rating: 4.7,
      reviews: 156,
      category: 'tools',
      image: 'https://readdy.ai/api/search-image?query=digital%20art%20creation%20tool%20interface%2C%20image%20generation%20software%2C%20creative%20design%20platform%2C%20modern%20UI%20elements%2C%20colorful%20gradient%20background%2C%20artistic%20visualization%2C%20professional%20design%20tools&width=150&height=150&seq=image-tool-1&orientation=squarish'
    },
    {
      id: 3,
      title: 'Thai Language Dataset',
      description: 'ชุดข้อมูลภาษาไทย 1M คำ',
      price: '฿599',
      rating: 4.8,
      reviews: 89,
      category: 'datasets',
      image: 'https://readdy.ai/api/search-image?query=data%20visualization%20with%20Thai%20language%20elements%2C%20database%20structure%2C%20information%20networks%2C%20data%20analytics%2C%20blue%20and%20green%20gradient%2C%20modern%20data%20representation%2C%20structured%20information%20display&width=150&height=150&seq=thai-dataset-1&orientation=squarish'
    },
    {
      id: 4,
      title: 'Business Card Templates',
      description: 'แม่แบบนามบัตรสำหรับธุรกิจ',
      price: '฿299',
      rating: 4.6,
      reviews: 67,
      category: 'templates',
      image: 'https://readdy.ai/api/search-image?query=elegant%20business%20card%20templates%2C%20professional%20design%20layouts%2C%20modern%20corporate%20identity%2C%20minimalist%20design%2C%20clean%20typography%2C%20business%20stationery%2C%20premium%20quality%20templates&width=150&height=150&seq=business-template-1&orientation=squarish'
    },
    {
      id: 5,
      title: 'Voice Synthesis Engine',
      description: 'โมเดลสังเคราะห์เสียงธรรมชาติ',
      price: '฿2,199',
      rating: 4.9,
      reviews: 145,
      category: 'models',
      image: 'https://readdy.ai/api/search-image?query=voice%20synthesis%20visualization%2C%20audio%20waveforms%2C%20sound%20engineering%20interface%2C%20AI%20voice%20technology%2C%20purple%20and%20blue%20gradient%2C%20modern%20audio%20processing%2C%20digital%20sound%20waves&width=150&height=150&seq=voice-model-1&orientation=squarish'
    },
    {
      id: 6,
      title: 'SEO Content Generator',
      description: 'เครื่องมือสร้างเนื้อหา SEO',
      price: '฿799',
      rating: 4.5,
      reviews: 78,
      category: 'tools',
      image: 'https://readdy.ai/api/search-image?query=SEO%20content%20creation%20interface%2C%20digital%20marketing%20tools%2C%20search%20engine%20optimization%2C%20content%20strategy%20visualization%2C%20green%20and%20blue%20gradient%2C%20modern%20marketing%20platform&width=150&height=150&seq=seo-tool-1&orientation=squarish'
    }
  ];

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(product => product.category === activeCategory);

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="relative w-full h-40 mb-6 rounded-2xl overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=digital%20marketplace%20with%20shopping%20interface%2C%20AI%20technology%20products%2C%20e-commerce%20platform%2C%20modern%20shopping%20experience%2C%20technology%20store%2C%20digital%20products%20showcase%2C%20futuristic%20retail%20concept&width=350&height=160&seq=marketplace-hero&orientation=landscape"
                alt="Marketplace"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">ตลาดซื้อขาย</h1>
            <p className="text-gray-600 text-sm">เครื่องมือและโมเดล AI คุณภาพสูง</p>
          </div>

          {/* Search Bar */}
          <div className="relative mb-6">
            <input
              type="text"
              placeholder="ค้นหาสินค้า..."
              className="w-full px-4 py-3 pl-12 pr-12 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
            <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <button className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400">
              <i className="ri-filter-line"></i>
            </button>
          </div>

          {/* Categories */}
          <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors !rounded-button ${
                  activeCategory === category.id
                    ? 'bg-blue-500 text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <i className={`${category.icon} mr-2`}></i>
                {category.name}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 gap-4">
            {filteredProducts.map((product) => (
              <Link
                key={product.id}
                href={`/marketplace/product/${product.id}`}
                className="bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800 text-sm mb-1 truncate">
                      {product.title}
                    </h3>
                    <p className="text-gray-600 text-xs mb-2 line-clamp-2">
                      {product.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="flex items-center mr-2">
                          <i className="ri-star-fill text-yellow-400 text-xs mr-1"></i>
                          <span className="text-xs text-gray-600">{product.rating}</span>
                        </div>
                        <span className="text-xs text-gray-500">({product.reviews})</span>
                      </div>
                      <span className="font-bold text-blue-600 text-sm">{product.price}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* My Products Section */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">สินค้าของฉัน</h3>
              <Link
                href="/marketplace/my-products"
                className="text-blue-600 text-sm font-medium hover:text-blue-700"
              >
                ดูทั้งหมด
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/marketplace/sell"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-add-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">ขายสินค้า</span>
              </Link>
              <Link
                href="/marketplace/earnings"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-money-dollar-circle-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">รายได้</span>
              </Link>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}