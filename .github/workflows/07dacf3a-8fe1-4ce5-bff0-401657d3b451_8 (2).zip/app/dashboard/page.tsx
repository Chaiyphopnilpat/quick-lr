'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';

export default function DashboardPage() {
  const stats = [
    {
      title: 'รูปภาพที่สร้าง',
      value: '247',
      change: '+12%',
      icon: 'ri-image-line',
      color: 'text-purple-600'
    },
    {
      title: 'ข้อความที่วิเคราะห์',
      value: '89',
      change: '+8%',
      icon: 'ri-file-text-line',
      color: 'text-blue-600'
    },
    {
      title: 'ยอดชำระเงิน',
      value: '฿2,450',
      change: '+15%',
      icon: 'ri-money-dollar-circle-line',
      color: 'text-green-600'
    },
    {
      title: 'เครดิต AI',
      value: '150',
      change: '-5%',
      icon: 'ri-coin-line',
      color: 'text-orange-600'
    }
  ];

  const recentActivities = [
    {
      action: 'สร้างรูปภาพ',
      detail: 'โลโก้บริษัท ABC',
      time: '2 นาทีที่แล้ว',
      icon: 'ri-image-add-line',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      action: 'ชำระเงิน',
      detail: 'แพ็คเกจ Premium',
      time: '1 ชั่วโมงที่แล้ว',
      icon: 'ri-bank-card-line',
      color: 'bg-green-100 text-green-600'
    },
    {
      action: 'วิเคราะห์ข้อความ',
      detail: 'เอกสารรายงาน',
      time: '3 ชั่วโมงที่แล้ว',
      icon: 'ri-file-text-line',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      action: 'ซื้อเครื่องมือ',
      detail: 'AI Voice Generator',
      time: '1 วันที่แล้ว',
      icon: 'ri-shopping-cart-line',
      color: 'bg-orange-100 text-orange-600'
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="relative w-full h-40 mb-6 rounded-2xl overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=modern%20analytics%20dashboard%20with%20charts%20graphs%20and%20data%20visualization%2C%20business%20intelligence%20interface%2C%20blue%20and%20purple%20gradient%2C%20clean%20minimalist%20design%2C%20financial%20charts%2C%20performance%20metrics%2C%20digital%20screens%2C%20high-tech%20monitoring%20system&width=350&height=160&seq=dashboard-hero&orientation=landscape"
                alt="Dashboard"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">แดshboard</h1>
            <p className="text-gray-600 text-sm">ภาพรวมการใช้งานของคุณ</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center`}>
                    <i className={`${stat.icon} ${stat.color} text-sm`}></i>
                  </div>
                  <span className={`text-xs font-medium ${
                    stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <div className="text-2xl font-bold text-gray-800 mb-1">
                  {stat.value}
                </div>
                <div className="text-xs text-gray-500">
                  {stat.title}
                </div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">การดำเนินการด่วน</h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                href="/ai-tools/image"
                className="flex items-center justify-center p-3 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors"
              >
                <i className="ri-image-add-line text-purple-600 mr-2"></i>
                <span className="text-sm font-medium text-purple-600">สร้างรูปภาพ</span>
              </Link>
              <Link
                href="/payment"
                className="flex items-center justify-center p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <i className="ri-wallet-line text-green-600 mr-2"></i>
                <span className="text-sm font-medium text-green-600">เติมเครดิต</span>
              </Link>
              <Link
                href="/marketplace"
                className="flex items-center justify-center p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
              >
                <i className="ri-store-line text-blue-600 mr-2"></i>
                <span className="text-sm font-medium text-blue-600">ตลาดซื้อขาย</span>
              </Link>
              <Link
                href="/security"
                className="flex items-center justify-center p-3 bg-red-50 rounded-xl hover:bg-red-100 transition-colors"
              >
                <i className="ri-shield-check-line text-red-600 mr-2"></i>
                <span className="text-sm font-medium text-red-600">ความปลอดภัย</span>
              </Link>
            </div>
          </div>

          {/* Recent Activities */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">กิจกรรมล่าสุด</h3>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-start">
                  <div className={`w-8 h-8 rounded-lg ${activity.color} flex items-center justify-center mr-3 mt-1`}>
                    <i className={`${activity.icon} text-xs`}></i>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-800 text-sm">{activity.action}</h4>
                      <span className="text-xs text-gray-500">{activity.time}</span>
                    </div>
                    <p className="text-gray-600 text-xs mt-1">{activity.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}