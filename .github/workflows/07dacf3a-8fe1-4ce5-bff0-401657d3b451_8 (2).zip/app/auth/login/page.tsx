
'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const router = useRouter();

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mounted) return;
    
    setIsLoading(true);
    
    // Simulate login process
    setTimeout(() => {
      if (mounted) {
        setIsLoading(false);
        // Use Next.js router instead of window.location.href
        router.push('/dashboard');
      }
    }, 2000);
  };

  const handleGoogleLogin = () => {
    if (!mounted) return;
    // Simulate Google login
    router.push('/dashboard');
  };

  const handleFacebookLogin = () => {
    if (!mounted) return;
    // Simulate Facebook login
    router.push('/dashboard');
  };

  if (!mounted) {
    return null; // or a loading skeleton
  }

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-user-line text-white text-2xl"></i>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">เข้าสู่ระบบ</h1>
            <p className="text-gray-600 text-sm">ยินดีต้อนรับกลับมา</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    อีเมล
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-4 py-3 pl-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="กรอกอีเมลของคุณ"
                      required
                    />
                    <i className="ri-mail-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    รหัสผ่าน
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 pl-12 pr-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="กรอกรหัสผ่านของคุณ"
                      required
                    />
                    <i className="ri-lock-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400"
                    >
                      <i className={showPassword ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      className="custom-checkbox"
                    />
                    <div className="w-5 h-5 border-2 border-gray-300 rounded flex items-center justify-center mr-2">
                      <i className="ri-check-line text-white text-xs opacity-0"></i>
                    </div>
                    <span className="text-sm text-gray-600">จดจำฉัน</span>
                  </label>
                  <Link href="/auth/forgot-password" className="text-sm text-blue-600 hover:text-blue-700">
                    ลืมรหัสผ่าน?
                  </Link>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 rounded-xl font-medium !rounded-button hover:shadow-lg transition-shadow disabled:opacity-50"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  กำลังเข้าสู่ระบบ...
                </div>
              ) : (
                'เข้าสู่ระบบ'
              )}
            </button>

            <div className="text-center">
              <span className="text-sm text-gray-600">
                ยังไม่มีบัญชี?{' '}
                <Link href="/auth/register" className="text-blue-600 hover:text-blue-700 font-medium">
                  สมัครสมาชิก
                </Link>
              </span>
            </div>
          </form>

          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">หรือ</span>
              </div>
            </div>

            <div className="mt-6 space-y-3">
              <button 
                onClick={handleGoogleLogin}
                className="w-full bg-white border border-gray-200 text-gray-700 py-3 rounded-xl font-medium !rounded-button hover:shadow-md transition-shadow flex items-center justify-center"
              >
                <i className="ri-google-line mr-2 text-red-500"></i>
                เข้าสู่ระบบด้วย Google
              </button>
              <button 
                onClick={handleFacebookLogin}
                className="w-full bg-white border border-gray-200 text-gray-700 py-3 rounded-xl font-medium !rounded-button hover:shadow-md transition-shadow flex items-center justify-center"
              >
                <i className="ri-facebook-line mr-2 text-blue-600"></i>
                เข้าสู่ระบบด้วย Facebook
              </button>
            </div>
          </div>
        </div>
      </div>
      <BottomTabBar />
    </>
  );
}
