'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function AIToolsPage() {
  const [activeTab, setActiveTab] = useState('image');

  const tools = [
    {
      id: 'image',
      title: 'สร้างรูปภาพ',
      icon: 'ri-image-line',
      description: 'แปลงข้อความเป็นภาพด้วย AI',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'text',
      title: 'วิเคราะห์ข้อความ',
      icon: 'ri-file-text-line',
      description: 'สรุปและวิเคราะห์เนื้อหาอัตโนมัติ',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'voice',
      title: 'แปลงเสียง',
      icon: 'ri-mic-line',
      description: 'แปลงเสียงเป็นข้อความ',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 'translate',
      title: 'แปลภาษา',
      icon: 'ri-translate-line',
      description: 'แปลภาษาด้วย AI',
      color: 'from-orange-500 to-red-500'
    }
  ];

  const recentProjects = [
    {
      title: 'โลโก้บริษัท',
      type: 'รูปภาพ',
      date: '2 ชั่วโมงที่แล้ว',
      status: 'เสร็จสิ้น'
    },
    {
      title: 'สรุปรายงาน',
      type: 'ข้อความ',
      date: '5 ชั่วโมงที่แล้ว',
      status: 'กำลังประมวลผล'
    },
    {
      title: 'แปลเอกสาร',
      type: 'แปลภาษา',
      date: '1 วันที่แล้ว',
      status: 'เสร็จสิ้น'
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="relative w-full h-40 mb-6 rounded-2xl overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=artificial%20intelligence%20brain%20neural%20network%20with%20holographic%20interface%2C%20digital%20AI%20technology%2C%20cyberpunk%20aesthetic%2C%20purple%20and%20blue%20neon%20glow%2C%20futuristic%20UI%20elements%2C%20machine%20learning%20visualization%2C%20high-tech%20dashboard%2C%20modern%20technology%20concept&width=350&height=160&seq=ai-tools-hero&orientation=landscape"
                alt="AI Tools"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">เครื่องมือ AI</h1>
            <p className="text-gray-600 text-sm">สร้างสรรค์ด้วยพลัง AI</p>
          </div>

          {/* Tools Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {tools.map((tool) => (
              <Link
                key={tool.id}
                href={`/ai-tools/${tool.id}`}
                className="bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${tool.color} flex items-center justify-center mb-3`}>
                  <i className={`${tool.icon} text-white text-lg`}></i>
                </div>
                <h3 className="font-semibold text-gray-800 text-sm mb-1">
                  {tool.title}
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed">
                  {tool.description}
                </p>
              </Link>
            ))}
          </div>

          {/* Recent Projects */}
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">โครงการล่าสุด</h3>
            <div className="space-y-4">
              {recentProjects.map((project, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-3">
                      <i className="ri-file-line text-gray-600"></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 text-sm">{project.title}</h4>
                      <p className="text-gray-500 text-xs">{project.type} • {project.date}</p>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs ${
                    project.status === 'เสร็จสิ้น' 
                      ? 'bg-green-100 text-green-600' 
                      : 'bg-yellow-100 text-yellow-600'
                  }`}>
                    {project.status}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Usage Stats */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-4">การใช้งานวันนี้</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">12</div>
                <div className="text-xs text-gray-500">รูปภาพ</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">8</div>
                <div className="text-xs text-gray-500">ข้อความ</div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}