'use client';

import Navigation from '@/components/Navigation';
import BottomTabBar from '@/components/BottomTabBar';
import Link from 'next/link';
import { useState } from 'react';

export default function PaymentPage() {
  const [activeTab, setActiveTab] = useState('wallet');

  const packages = [
    {
      title: 'Basic',
      price: '฿199',
      period: '/เดือน',
      credits: '100',
      features: ['รูปภาพ 50 ชิ้น', 'วิเคราะห์ข้อความ 25 ครั้ง', 'Support พื้นฐาน'],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Premium',
      price: '฿499',
      period: '/เดือน',
      credits: '300',
      features: ['รูปภาพ 150 ชิ้น', 'วิเคราะห์ข้อความ 75 ครั้ง', 'Support 24/7', 'เครื่องมือพิเศษ'],
      color: 'from-purple-500 to-pink-500',
      popular: true
    },
    {
      title: 'Enterprise',
      price: '฿999',
      period: '/เดือน',
      credits: '1000',
      features: ['รูปภาพไม่จำกัด', 'วิเคราะห์ข้อความไม่จำกัด', 'API Access', 'Custom Model'],
      color: 'from-orange-500 to-red-500'
    }
  ];

  const transactions = [
    {
      type: 'เติมเครดิต',
      amount: '+100',
      price: '฿199',
      date: '15/01/2025',
      status: 'สำเร็จ'
    },
    {
      type: 'ใช้เครดิต',
      amount: '-15',
      price: 'สร้างรูปภาพ',
      date: '14/01/2025',
      status: 'สำเร็จ'
    },
    {
      type: 'ใช้เครดิต',
      amount: '-8',
      price: 'วิเคราะห์ข้อความ',
      date: '13/01/2025',
      status: 'สำเร็จ'
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-24">
        <div className="max-w-sm mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="relative w-full h-40 mb-6 rounded-2xl overflow-hidden">
              <img
                src="https://readdy.ai/api/search-image?query=digital%20wallet%20payment%20system%20with%20credit%20cards%2C%20mobile%20payment%20interface%2C%20financial%20technology%2C%20secure%20transactions%2C%20green%20and%20blue%20gradient%2C%20modern%20banking%20design%2C%20cryptocurrency%20elements%2C%20fintech%20visualization&width=350&height=160&seq=payment-hero&orientation=landscape"
                alt="Payment"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">ระบบชำระเงิน</h1>
            <p className="text-gray-600 text-sm">จัดการการเงินและเครดิต</p>
          </div>

          {/* Wallet Balance */}
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-6 text-white mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-green-100 text-sm">ยอดเครดิตคงเหลือ</p>
                <p className="text-3xl font-bold">150</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <i className="ri-wallet-line text-2xl"></i>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-green-100 text-sm">มูลค่า: ฿1,500</span>
              <Link
                href="/payment/topup"
                className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-medium transition-colors !rounded-button"
              >
                เติมเครดิต
              </Link>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex bg-white rounded-2xl p-1 mb-6">
            <button
              onClick={() => setActiveTab('wallet')}
              className={`flex-1 py-3 px-4 rounded-xl text-sm font-medium transition-colors !rounded-button ${
                activeTab === 'wallet'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              กระเป๋าเงิน
            </button>
            <button
              onClick={() => setActiveTab('packages')}
              className={`flex-1 py-3 px-4 rounded-xl text-sm font-medium transition-colors !rounded-button ${
                activeTab === 'packages'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              แพ็คเกจ
            </button>
          </div>

          {activeTab === 'wallet' && (
            <div className="space-y-6">
              {/* Transactions */}
              <div className="bg-white rounded-2xl p-6 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4">ประวัติการทำรายการ</h3>
                <div className="space-y-4">
                  {transactions.map((transaction, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                          transaction.type === 'เติมเครดิต' 
                            ? 'bg-green-100 text-green-600' 
                            : 'bg-blue-100 text-blue-600'
                        }`}>
                          <i className={`${
                            transaction.type === 'เติมเครดิต' 
                              ? 'ri-add-line' 
                              : 'ri-subtract-line'
                          } text-sm`}></i>
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800 text-sm">{transaction.type}</h4>
                          <p className="text-gray-500 text-xs">{transaction.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-medium text-sm ${
                          transaction.amount.startsWith('+') 
                            ? 'text-green-600' 
                            : 'text-blue-600'
                        }`}>
                          {transaction.amount}
                        </div>
                        <div className="text-gray-500 text-xs">{transaction.price}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Payment Methods */}
              <div className="bg-white rounded-2xl p-6 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4">วิธีการชำระเงิน</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border border-gray-200 rounded-xl">
                    <div className="flex items-center">
                      <i className="ri-bank-card-line text-blue-600 mr-3"></i>
                      <span className="text-sm font-medium text-gray-800">**** **** **** 1234</span>
                    </div>
                    <span className="text-xs text-gray-500">หลัก</span>
                  </div>
                  <Link
                    href="/payment/methods"
                    className="flex items-center justify-center p-3 border-2 border-dashed border-gray-300 rounded-xl hover:border-gray-400 transition-colors"
                  >
                    <i className="ri-add-line text-gray-500 mr-2"></i>
                    <span className="text-sm text-gray-500">เพิ่มวิธีชำระเงิน</span>
                  </Link>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'packages' && (
            <div className="space-y-4">
              {packages.map((pkg, index) => (
                <div key={index} className={`bg-white rounded-2xl p-6 shadow-sm relative ${
                  pkg.popular ? 'ring-2 ring-purple-500' : ''
                }`}>
                  {pkg.popular && (
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                      <span className="bg-purple-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                        แนะนำ
                      </span>
                    </div>
                  )}
                  <div className="text-center mb-4">
                    <h3 className="font-bold text-gray-800 text-lg mb-1">{pkg.title}</h3>
                    <div className="flex items-end justify-center mb-2">
                      <span className="text-3xl font-bold text-gray-800">{pkg.price}</span>
                      <span className="text-gray-500 text-sm ml-1">{pkg.period}</span>
                    </div>
                    <p className="text-sm text-gray-600">{pkg.credits} เครดิต</p>
                  </div>
                  <div className="space-y-2 mb-6">
                    {pkg.features.map((feature, i) => (
                      <div key={i} className="flex items-center">
                        <i className="ri-check-line text-green-500 mr-2 text-sm"></i>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <button className={`w-full py-3 rounded-xl font-medium text-white bg-gradient-to-r ${pkg.color} hover:shadow-lg transition-shadow !rounded-button`}>
                    เลือกแพ็คเกจ
                  </button>
                </div>
              ))}
            </div>
          )}

        </div>
      </div>
      <BottomTabBar />
    </>
  );
}