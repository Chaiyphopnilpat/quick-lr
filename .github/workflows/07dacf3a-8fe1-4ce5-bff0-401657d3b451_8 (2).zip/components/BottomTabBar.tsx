
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function BottomTabBar() {
  const pathname = usePathname();

  const tabs = [
    { href: '/', icon: 'ri-home-line', label: 'หน้าหลัก' },
    { href: '/marketplace/earnings', icon: 'ri-store-line', label: 'POS' },
    { href: '/marketplace', icon: 'ri-shopping-bag-line', label: 'ตลาด' },
    { href: '/dashboard', icon: 'ri-dashboard-line', label: 'รายงาน' },
    { href: '/profile', icon: 'ri-user-line', label: 'โปรไฟล์' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 z-50">
      <div className="max-w-sm mx-auto grid grid-cols-5 py-2">
        {tabs.map((tab) => (
          <Link
            key={tab.href}
            href={tab.href}
            className={`flex flex-col items-center justify-center py-2 px-1 ${
              pathname === tab.href || (tab.href === '/marketplace/earnings' && pathname.startsWith('/marketplace/earnings'))
                ? 'text-blue-600' 
                : 'text-gray-500'
            }`}
          >
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className={`${tab.icon} text-lg`}></i>
            </div>
            <span className="text-xs">{tab.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
