'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 px-4 py-3">
      <div className="max-w-sm mx-auto flex items-center justify-between">
        <Link href="/" className="text-2xl font-pacifico text-blue-600">
          AI Platform
        </Link>
        
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="w-8 h-8 flex items-center justify-center !rounded-button"
        >
          <i className="ri-menu-line text-xl"></i>
        </button>
      </div>

      {isMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-t border-gray-100 shadow-lg">
          <div className="max-w-sm mx-auto py-2">
            <Link
              href="/auth/login"
              className="block px-4 py-3 text-gray-700 hover:bg-gray-50"
              onClick={() => setIsMenuOpen(false)}
            >
              <i className="ri-login-box-line mr-2"></i>
              เข้าสู่ระบบ
            </Link>
            <Link
              href="/auth/register"
              className="block px-4 py-3 text-gray-700 hover:bg-gray-50"
              onClick={() => setIsMenuOpen(false)}
            >
              <i className="ri-user-add-line mr-2"></i>
              สมัครสมาชิก
            </Link>
            <Link
              href="/dashboard"
              className="block px-4 py-3 text-gray-700 hover:bg-gray-50"
              onClick={() => setIsMenuOpen(false)}
            >
              <i className="ri-dashboard-line mr-2"></i>
              แดชบอร์ด
            </Link>
            <Link
              href="/ai-tools"
              className="block px-4 py-3 text-gray-700 hover:bg-gray-50"
              onClick={() => setIsMenuOpen(false)}
            >
              <i className="ri-robot-line mr-2"></i>
              เครื่องมือ AI
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}